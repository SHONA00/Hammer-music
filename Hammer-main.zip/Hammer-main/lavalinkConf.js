module.exports = {
  shoukakuNodes: [
    { "name": "Node - 1", "url": "164.92.76.204:2333", "auth": "VoidOP", "secure": false },
  ]
}
